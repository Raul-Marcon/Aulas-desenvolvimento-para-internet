let inputum = document.getElementById("inputum");
let inputdois = document.getElementById("inputdois");
let botao = document.getElementById("botao");
let texto =document.getElementById("texto");

function somar() {
    let numeroum = Number(inputum.value);
    let numerodois = Number(inputdois.value);
    let resultado = numeroum - numerodois;
    texto.textContent = resultado;
    if(texto.textContent < 0) {
        texto.textContent = "O troco a ser dado é de " + resultado;
    }
    else {
        texto.textContent = resultado;
    }
}