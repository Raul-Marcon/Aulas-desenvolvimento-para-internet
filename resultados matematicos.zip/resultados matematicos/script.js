let inputum = document.getElementById("inputum");
let inputdois =document.getElementById("inputdois");
let texto = document.getElementById("texto");
let textodois = document.getElementById("textodois");
let textotres = document.getElementById("textotres");
let textoquatro =document.getElementById("textoquatro");

function soma() {
    num = Number(inputum.value);
    numdois = Number(inputdois.value);
    resultadoum = num + numdois;
    resultadodois = num - numdois;
    resultadotres = num * numdois;
    resultadoquatro = num / numdois;
    texto.textContent = resultadoum + " soma";
    textodois.textContent = resultadodois + " subtração";
    textotres.textContent = resultadotres + " multiplicação";
    textoquatro.textContent = resultadoquatro + " divisão";
}